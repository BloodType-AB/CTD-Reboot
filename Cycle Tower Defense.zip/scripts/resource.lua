return {
	Tower_SingleTarget_1 = {
		width = 100, 
		height = 86
	},
	range = {
		width = 300, 
		height = 300
	}, 
	TowerFrame = {
		width = 800, 
		height = 800
	}, 
	route = {
		width = 1200, 
		height = 1200
	}, 
	HPbar = {
		width = 51, 
		height = 12
	}
}